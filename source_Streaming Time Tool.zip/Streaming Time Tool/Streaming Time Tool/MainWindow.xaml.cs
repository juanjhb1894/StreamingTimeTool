﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net;
using System.Threading;
using System.IO;
using Arction.Gauges;
using Arction.Gauges.Dials;

namespace Streaming_Time_Tool
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 
    public partial class MainWindow : Window
    {
        HttpListener _httpListener = new HttpListener();
        string colorHex;
        string cdDateTime, cdSize;
        string date;
        string time;
        string clockColorHex, clockSize;
        public MainWindow()
        {
            InitializeComponent();
            ///Pre-Set
            cldSample.SelectedDate = DateTime.Now;
            CreateClock();

            txtTime.Text = "15:30:00";
        }

        private void RunCountDown()
        {
            _httpListener.Prefixes.Add("http://localhost:5000/countdown/"); // add prefix "http://localhost:5000/"
            _httpListener.Start(); // start server (Run application as Administrator!)
            Thread _responseThread = new Thread(ResponseThreadCD);
            _responseThread.Start(); // start the response thread
        }

        private void ResponseThreadCD()
        {
            while (true)
            {
                cdDateTime = date+" "+time;
                HttpListenerContext context = _httpListener.GetContext(); // get a context
                string body = File.ReadAllText("countdown.html"); // Now, you'll find the request URL in context.Request.Url
                string bodySetted = body.Replace("Jan 5, 2021 15:37:25", cdDateTime).Replace("color:#000000", colorHex).Replace("font-size: 60px;", cdSize); ;
                byte[] _responseArray = Encoding.UTF8.GetBytes(bodySetted); // get the bytes to response
                context.Response.OutputStream.Write(_responseArray, 0, _responseArray.Length); // write bytes to the output stream
                context.Response.KeepAlive = false; // set the KeepAlive bool to false
                context.Response.Close(); // close the connection
            }
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if ((txtColor.Text.Contains("#")&& txtColor.Text.Length == 7) || (!txtColor.Text.Contains("#") && txtColor.Text.Length == 6))
            {
                string color = txtColor.Text.Replace("#","");
                canvas.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#"+color));
                colorHex = "color:#" + color;

            }
        }

        private void RunCountDown_Click(object sender, RoutedEventArgs e)
        {
            RunCountDown();
        }

        private void CreateClock()
        {
            //declare some variables
            var ClockColor = new SolidColorBrush(Color.FromRgb(86, 104, 149));
            var ClockArcColor = new SolidColorBrush(Color.FromRgb(40, 44, 65));
            var ClockFontSize = 14;
            var ClockSize = 200;

            var DialColorHours = Color.FromRgb(131, 146, 187);
            var DialColorMinutes = Color.FromRgb(131, 146, 187);

            var LabelColorHours = Brushes.White;
            var LabelColorMinutes = Brushes.White;
            var LabelColorSeconds = Brushes.White;
            var FontFamily = new FontFamily("Arial");

            //some clock default stuff
            Clock.Fill = ClockColor;
            Clock.FontSize = ClockFontSize;
            Clock.Height = ClockSize;
            Clock.Stroke = ClockArcColor;
            Clock.StrokeThickness = 5;
            Clock.Width = ClockSize;

            //create the hour scales
            var Hours = new Scale()
            {
                AngleBegin = 60,
                AngleEnd = 60,
                ArcStrokeThickness = 2,
                ArcStroke = ClockArcColor,
                DialColor1 = DialColorHours,
                DialLengthFactor = 0.6,
                DialShape = DialShape.DefaultNeedle,
                Label = new TextBlock(),
                MajorTickCount = 12,
                MinorTickCount = 0,
                RangeBegin = 1,
                RangeEnd = 13,
                ValueIndicatorDistance = -99999,
                MajorTicks = new MajorTicksLine()
                {
                    FontFamily = FontFamily,
                    FontWeight = FontWeights.Bold,
                    LabelBrush = LabelColorHours,
                    LabelOffset = -12,
                    OffsetA = -5,
                    TickStroke = LabelColorHours,
                }
            };

            //create the minute scales
            var Minutes = new Scale()
            {
                AngleBegin = 90,
                AngleEnd = 90,
                DialColor1 = DialColorMinutes,
                DialLengthFactor = 0.8,
                DialShape = DialShape.DefaultNeedle,
                MajorTickCount = 60,
                MinorTickCount = 0,
                RangeBegin = 0,
                RangeEnd = 60,
                Theme = ScaleThemeEnum.None,
                MajorTicks = new MajorTicksLine()
                {
                    LabelBrush = LabelColorMinutes,
                    LabelsEnabled = false,
                    OffsetA = -4,
                    OffsetB = -2,
                    TickStroke = LabelColorMinutes,
                    TickThickness = 2
                }
            };

            //create the second scales
            var Seconds = new Scale()
            {
                AngleBegin = 90,
                AngleEnd = 90,
                DialLengthFactor = 0.8,
                DialShape = DialShape.Line,
                MajorTickCount = 60,
                MinorTickCount = 0,
                RangeBegin = 0,
                RangeEnd = 60,
                Theme = ScaleThemeEnum.None,
                MajorTicks = new MajorTicksLine()
                {
                    LabelsEnabled = false,
                    OffsetA = -4,
                    OffsetB = -2,
                    TickStroke = LabelColorSeconds,
                    TickThickness = 2
                }
            };

            //add the scales to the clock
            Clock.PrimaryScale = Hours;
            Clock.SecondaryScales.Add(Minutes);
            Clock.SecondaryScales.Add(Seconds);

            //set the current time
            Clock.PrimaryScale.Value = DateTime.Now.Hour;
            Clock.SecondaryScales[0].Value = DateTime.Now.Minute;
            Clock.SecondaryScales[1].Value = DateTime.Now.Second;
        }



        private void TxtDate_TextChanged(object sender, TextChangedEventArgs e)
        {
            cldSample.SelectedDate = DateTime.Parse(txtDate.Text);
            date = txtDate.Text;
        }

        private void onTextChanged(object sender, TextChangedEventArgs e)
        {
            if (txtTime.Text.Split(':').Length==3 &&
                (txtTime.Text.Split(':')[0].Length >= 1 && txtTime.Text.Split(':')[0].Length <= 2) &&
                (txtTime.Text.Split(':')[1].Length >= 1 && txtTime.Text.Split(':')[1].Length <= 2) &&
                (txtTime.Text.Split(':')[2].Length >= 1 && txtTime.Text.Split(':')[2].Length <= 2))
            {
                time = txtTime.Text;
                //set the current time
                string[] arrTime = time.Split(':');
                DateTime datetime = DateTime.Now;
                datetime = new DateTime(datetime.Year, datetime.Month, datetime.Day, Convert.ToInt32(arrTime[0]), Convert.ToInt32(arrTime[1]), Convert.ToInt32(arrTime[2]));

                Clock.PrimaryScale.Value = datetime.Hour;
                Clock.SecondaryScales[0].Value = datetime.Minute;
                Clock.SecondaryScales[1].Value = datetime.Second;
            }
            
        }

        private void RunClock_Click(object sender, RoutedEventArgs e)
        {
            RunClock();
        }

        private void RunClock()
        {
            _httpListener.Prefixes.Add("http://localhost:5000/clock/"); // add prefix "http://localhost:5000/"
            _httpListener.Start(); // start server (Run application as Administrator!)
            Thread _responseThread = new Thread(ResponseThreadClock);
            _responseThread.Start(); // start the response thread
        }

        private void ResponseThreadClock()
        {
            while (true)
            {
                HttpListenerContext context = _httpListener.GetContext(); // get a context
                string body = File.ReadAllText("clock.html"); // Now, you'll find the request URL in context.Request.Url
                string bodySetted = body.Replace("color:#000000", clockColorHex).Replace("font-size: 60px;", clockSize);
                byte[] _responseArray = Encoding.UTF8.GetBytes(bodySetted); // get the bytes to response
                context.Response.OutputStream.Write(_responseArray, 0, _responseArray.Length); // write bytes to the output stream
                context.Response.KeepAlive = false; // set the KeepAlive bool to false
                context.Response.Close(); // close the connection
            }
        }

        private void TxtClockColor_TextChanged(object sender, TextChangedEventArgs e)
        {
            if ((txtClockColor.Text.Contains("#") && txtClockColor.Text.Length == 7) || (!txtClockColor.Text.Contains("#") && txtClockColor.Text.Length == 6))
            {
                string color = txtColor.Text.Replace("#", "");
                canvas.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#" + color));
                clockColorHex = "color:#" + color;

            }
        }

        private void TxtCountdownSize_TextChanged(object sender, TextChangedEventArgs e)
        {
            cdSize = string.Format("font-size: {0}px;", txtCountdownSize.Text.Replace("px", ""));

        }

        private void TxtClockSize_TextChanged(object sender, TextChangedEventArgs e)
        {
            clockSize = string.Format("font-size: {0}px;", txtClockSize.Text.Replace("px",""));
        }
    }
}
